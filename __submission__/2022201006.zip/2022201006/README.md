> ### For switching from `command` to `normal` MODE type "switch"  and then press ENTER;

<br/>

#### Misc:
- > `main.cpp` requires `__utils__.h` and `__fstatutils__.h` to run
- > These are custom header files created for modularity
- > Keep both these files in the same directory as the `main.cpp` file
